TF2 Sound Converter v4

Audio stays local so no server and its not sent anywhere

message me if you have any problems

please dont steal my thingy
